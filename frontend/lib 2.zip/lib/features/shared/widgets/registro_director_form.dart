import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../../director/controller/usuarios_controller.dart';
import '../../director/models/usuario_request.dart';

class RegistroDirectorForm extends StatefulWidget {
  const RegistroDirectorForm({super.key});

  @override
  State<RegistroDirectorForm> createState() => _RegistroDirectorFormState();
}

class _RegistroDirectorFormState extends State<RegistroDirectorForm> {
  final _formKey = GlobalKey<FormState>();
  final _nombres = TextEditingController();
  final _apellidoPaterno = TextEditingController();
  final _apellidoMaterno = TextEditingController();
  final _correo = TextEditingController();
  final _password = TextEditingController();

  File? _fotoSeleccionada;
  String? _fotoPerfilUrl;

  @override
  void dispose() {
    _nombres.dispose();
    _apellidoPaterno.dispose();
    _apellidoMaterno.dispose();
    _correo.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _seleccionarFoto() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _fotoSeleccionada = File(pickedFile.path);
        _fotoPerfilUrl = pickedFile.path;
      });
    }
  }

  void _submit() async {
    if (!_formKey.currentState!.validate()) return;

    final dto = UsuarioRequestDTO(
      nombres: _nombres.text.trim(),
      apellidoPaterno: _apellidoPaterno.text.trim(),
      apellidoMaterno: _apellidoMaterno.text.trim(),
      correo: _correo.text.trim(),
      password: _password.text.trim(),
      fotoPerfilUrl: _fotoPerfilUrl,
    );

    final controller = context.read<UsuariosController>();
    await controller.registrarDirector(dto);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Director registrado')),
    );
    _formKey.currentState!.reset();
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Registrar Director')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _nombres,
                decoration: const InputDecoration(labelText: 'Nombres'),
                validator: (v) => v == null || v.isEmpty ? 'Campo obligatorio' : null,
              ),
              TextFormField(
                controller: _apellidoPaterno,
                decoration: const InputDecoration(labelText: 'Apellido paterno'),
                validator: (v) => v == null || v.isEmpty ? 'Campo obligatorio' : null,
              ),
              TextFormField(
                controller: _apellidoMaterno,
                decoration: const InputDecoration(labelText: 'Apellido materno (opcional)'),
              ),
              TextFormField(
                controller: _correo,
                decoration: const InputDecoration(labelText: 'Correo electrónico'),
                validator: (v) {
                  if (v == null || v.isEmpty) return 'Campo obligatorio';
                  final regex = RegExp(r'^[^@]+@[^@]+\.[^@]+$');
                  return regex.hasMatch(v) ? null : 'Correo inválido';
                },
              ),
              TextFormField(
                controller: _password,
                decoration: const InputDecoration(labelText: 'Contraseña'),
                obscureText: true,
                validator: (v) => v == null || v.isEmpty ? 'Campo obligatorio' : null,
              ),
              const SizedBox(height: 16),
              TextButton.icon(
                onPressed: _seleccionarFoto,
                icon: const Icon(Icons.image),
                label: const Text('Seleccionar Foto de Perfil'),
              ),
              if (_fotoSeleccionada != null)
                Image.file(_fotoSeleccionada!, height: 100),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _submit,
                child: const Text('Registrar Director'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
