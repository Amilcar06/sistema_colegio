// lib/features/auth/ui/login_page.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:dio/dio.dart';
import '../../../core/api.dart';
import '../../../state/auth_provider.dart';
import 'package:go_router/go_router.dart'; // <- Asegúrate de importar esto


class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final emailController = TextEditingController();
  final passController = TextEditingController();
  bool isLoading = false;
  String? error;

  void login() async {
    setState(() {
      isLoading = true;
      error = null;
    });

    try {
      final response = await dio.post('/auth/login', data: {
        "correo": emailController.text.trim(),
        "password": passController.text.trim(),
      });

      final token = response.data['token'];
      final rol = response.data['rol'];

      //print('ROL RECIBIDO: $rol');

      final auth = Provider.of<AuthProvider>(context, listen: false);
      await auth.login(token, rol);

      if (rol.toLowerCase() == 'director') {
        context.go('/dashboard-director');
      } else if (rol.toLowerCase() == 'profesor') {
        context.go('/dashboard-profesor');
      } else if (rol.toLowerCase() == 'alumno') {
        context.go('/dashboard-alumno');
      } else if (rol.toLowerCase() == 'secretaria') {
        context.go('/dashboard-secretaria');
      }

    } on DioException catch (e) {
      setState(() {
        error = e.response?.data['message'] ?? 'Error al iniciar sesión';
      });
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Iniciar Sesión')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            if (error != null)
              Text(error!, style: const TextStyle(color: Colors.red)),
            TextField(
              controller: emailController,
              decoration: const InputDecoration(labelText: 'Correo'),
            ),
            TextField(
              controller: passController,
              decoration: const InputDecoration(labelText: 'Contraseña'),
              obscureText: true,
            ),
            const SizedBox(height: 20),
            isLoading
                ? const CircularProgressIndicator()
                : ElevatedButton(
              onPressed: login,
              child: const Text('Ingresar'),
            ),
          ],
        ),
      ),
    );
  }
}
