import '../../../core/api.dart';
import '../models/profesor_registro_completo.dart';
import '../models/profesor_response.dart';

class ProfesorService {
  Future<List<ProfesorResponseDTO>> listarProfesores() async {
    final response = await dio.get('/profesores');
    return (response.data as List)
        .map((e) => ProfesorResponseDTO.fromJson(e))
        .toList();
  }

  Future<ProfesorResponseDTO> registrarProfesorCompleto(ProfesorRegistroCompletoDTO dto) async {
    final response = await dio.post('/profesores/registro-completo', data: dto.toJson());
    return ProfesorResponseDTO.fromJson(response.data);
  }

  Future<ProfesorResponseDTO> actualizarProfesor(int idProfesor, ProfesorRegistroCompletoDTO dto) async {
    final response = await dio.put('/profesores/$idProfesor', data: dto.toJson());
    return ProfesorResponseDTO.fromJson(response.data);
  }

  Future<void> eliminarProfesor(int idProfesor) async {
    await dio.delete('/profesores/$idProfesor');
  }
}