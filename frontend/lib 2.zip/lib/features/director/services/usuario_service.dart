import 'package:unidad_educatica_frontend/core/api.dart';
import '../models/usuario_request.dart';
import '../models/usuario_response.dart';

class UsuarioService {
  Future<UsuarioResponseDTO> registrarDirector(UsuarioRequestDTO dto) async {
    final response = await dio.post('/usuarios/registro-director', data: dto.toJson());
    return UsuarioResponseDTO.fromJson(response.data);
  }

  Future<UsuarioResponseDTO> registrarSecretaria(UsuarioRequestDTO dto) async {
    final response = await dio.post('/usuarios/registro-secretaria', data: dto.toJson());
    return UsuarioResponseDTO.fromJson(response.data);
  }

  Future<List<UsuarioResponseDTO>> listarUsuarios() async {
    final response = await dio.get('/usuarios');
    return (response.data as List)
        .map((e) => UsuarioResponseDTO.fromJson(e))
        .toList();
  }
}
