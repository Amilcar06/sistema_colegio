class UsuarioResponseDTO {
  final int idUsuario;
  final String nombres;
  final String apellidoPaterno;
  final String? apellidoMaterno;
  final String correo;
  final String? fotoPerfilUrl;
  final bool estado;
  final String rol; // extraído de rol.nombre

  UsuarioResponseDTO({
    required this.idUsuario,
    required this.nombres,
    required this.apellidoPaterno,
    this.apellidoMaterno,
    required this.correo,
    this.fotoPerfilUrl,
    required this.estado,
    required this.rol,
  });

  factory UsuarioResponseDTO.fromJson(Map<String, dynamic> json) {
    return UsuarioResponseDTO(
      idUsuario: json['idUsuario'],
      nombres: json['nombres'],
      apellidoPaterno: json['apellidoPaterno'],
      apellidoMaterno: json['apellidoMaterno'],
      correo: json['correo'],
      fotoPerfilUrl: json['fotoPerfilUrl'],
      estado: json['estado'],
      rol: json['rol']?['nombre'] ?? 'SIN_ROL',
    );
  }
}
