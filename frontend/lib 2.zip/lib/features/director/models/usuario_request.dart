class UsuarioRequestDTO {
  final String nombres;
  final String apellidoPaterno;
  final String? apellidoMaterno;
  final String correo;
  final String password;
  final bool estado;
  final String? fotoPerfilUrl;

  UsuarioRequestDTO({
    required this.nombres,
    required this.apellidoPaterno,
    this.apellidoMaterno,
    required this.correo,
    required this.password,
    this.estado = true,
    this.fotoPerfilUrl,
  });

  Map<String, dynamic> toJson() => {
    'nombres': nombres,
    'apellidoPaterno': apellidoPaterno,
    'apellidoMaterno': apellidoMaterno,
    'correo': correo,
    'password': password,
    'estado': estado,
    'fotoPerfilUrl': fotoPerfilUrl,
  };
}
