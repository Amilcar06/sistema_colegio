import 'package:flutter/material.dart';
import '../models/usuario_request.dart';
import '../models/usuario_response.dart';
import '../services/usuario_service.dart';

class UsuariosController with ChangeNotifier {
  final UsuarioService _service = UsuarioService();

  List<UsuarioResponseDTO> usuarios = [];
  bool cargando = false;
  String? errorMessage;

  /// Cargar lista de usuarios
  Future<void> cargarUsuarios() async {
    cargando = true;
    errorMessage = null;
    notifyListeners();

    try {
      usuarios = await _service.listarUsuarios();
    } catch (e) {
      errorMessage = 'Error al cargar usuarios: $e';
    } finally {
      cargando = false;
      notifyListeners();
    }
  }

  /// Registrar un director y recargar lista
  Future<bool> registrarDirector(UsuarioRequestDTO dto) async {
    errorMessage = null;
    try {
      await _service.registrarDirector(dto);
      await cargarUsuarios();
      return true;
    } catch (e) {
      errorMessage = 'Error al registrar director: $e';
      notifyListeners();
      return false;
    }
  }

  /// Registrar una secretaria y recargar lista
  Future<bool> registrarSecretaria(UsuarioRequestDTO dto) async {
    errorMessage = null;
    try {
      await _service.registrarSecretaria(dto);
      await cargarUsuarios();
      return true;
    } catch (e) {
      errorMessage = 'Error al registrar secretaria: $e';
      notifyListeners();
      return false;
    }
  }
}
