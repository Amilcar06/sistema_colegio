import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../shared/widgets/main_scaffold.dart';
import '../../profesor/controller/profesor_controller.dart';
import '../../shared/widgets/registro_profesor_form.dart';

class DashboardDirectorProfesoresPage extends StatelessWidget {
  const DashboardDirectorProfesoresPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ProfesorController()..cargarProfesores(),
      child: Consumer<ProfesorController>(
        builder: (context, controller, _) {
          return MainScaffold(
            child: controller.cargando
                ? const Center(child: CircularProgressIndicator())
                : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  const RegistroProfesorForm(),
                  const Divider(),
                  if (controller.profesores.isEmpty)
                    const Text('No hay profesores registrados.'),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: controller.profesores.length,
                    itemBuilder: (context, index) {
                      final prof = controller.profesores[index];
                      return Card(
                        child: ListTile(
                          title: Text('${prof.nombres} ${prof.apellidoPaterno} ${prof.apellidoMaterno}'),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(prof.correo),
                              Text('CI: ${prof.ci}'),
                              Text('Profesión: ${prof.profesion ?? 'No especificado'}'),
                            ],
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit, color: Colors.orange),
                                onPressed: () {
                                  context.read<ProfesorController>().seleccionarParaEditar(prof);
                                },
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete, color: Colors.red),
                                onPressed: () async {
                                  final confirm = await showDialog<bool>(
                                    context: context,
                                    builder: (context) => AlertDialog(
                                      title: const Text('Confirmar eliminación'),
                                      content: const Text('¿Estás seguro de que deseas eliminar este profesor?'),
                                      actions: [
                                        TextButton(
                                          onPressed: () => Navigator.pop(context, false),
                                          child: const Text('Cancelar'),
                                        ),
                                        ElevatedButton(
                                          onPressed: () => Navigator.pop(context, true),
                                          child: const Text('Eliminar'),
                                        ),
                                      ],
                                    ),
                                  );
                                  if (confirm == true) {
                                    final exito = await controller.eliminarProfesor(prof.idProfesor);
                                    if (exito) {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(content: Text('Profesor eliminado exitosamente')),
                                      );
                                    } else {
                                      final error = controller.errorMessage ?? 'Error desconocido';
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(content: Text(error)),
                                      );
                                    }
                                  }
                                },
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
