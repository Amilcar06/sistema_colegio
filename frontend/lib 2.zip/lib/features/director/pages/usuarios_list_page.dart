import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controller/usuarios_controller.dart';
import '../../shared/widgets/registro_director_form.dart';
import '../../shared/widgets/registro_secretaria_form.dart';

class UsuariosListPage extends StatelessWidget {
  const UsuariosListPage({super.key});

  void _mostrarOpcionesRegistro(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.person),
            title: const Text('Registrar Director'),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ChangeNotifierProvider(
                    create: (_) => UsuariosController(),
                    child: const RegistroDirectorForm(),
                  ),
                ),
              );
            },
          ),
          ListTile(
            leading: const Icon(Icons.person_outline),
            title: const Text('Registrar Secretaria'),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ChangeNotifierProvider(
                    create: (_) => UsuariosController(),
                    child: const RegistroSecretariaForm(),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => UsuariosController()..cargarUsuarios(),
      child: Scaffold(
        appBar: AppBar(title: const Text('Usuarios')),
        body: Consumer<UsuariosController>(
          builder: (context, ctrl, _) {
            if (ctrl.cargando) {
              return const Center(child: CircularProgressIndicator());
            }

            if (ctrl.errorMessage != null) {
              return Center(child: Text(ctrl.errorMessage!));
            }

            if (ctrl.usuarios.isEmpty) {
              return const Center(child: Text('No hay usuarios registrados.'));
            }

            return ListView.separated(
              itemCount: ctrl.usuarios.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, index) {
                final u = ctrl.usuarios[index];
                return ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.person)),
                  title: Text('${u.nombres} ${u.apellidoPaterno}'),
                  subtitle: Text('${u.correo} - Rol: ${u.rol}'),
                  trailing: u.estado
                      ? const Icon(Icons.check_circle, color: Colors.green)
                      : const Icon(Icons.cancel, color: Colors.red),
                );
              },
            );
          },
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () => _mostrarOpcionesRegistro(context),
          child: const Icon(Icons.add),
        ),
      ),
    );
  }
}
