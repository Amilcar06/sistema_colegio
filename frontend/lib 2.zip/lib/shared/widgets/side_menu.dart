import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'menu/menu_items.dart';

class SideMenu extends StatelessWidget {
  final List<MenuItem> menu;

  const SideMenu({super.key, required this.menu});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          const DrawerHeader(
            decoration: BoxDecoration(color: Colors.blue),
            child: Text(
              'Menú',
              style: TextStyle(color: Colors.white, fontSize: 24),
            ),
          ),
          ...menu.map((item) {
            return ListTile(
              leading: Icon(item.icon),
              title: Text(item.label),
              onTap: () {
                context.go(item.route);
                Navigator.pop(context); // Cierra el Drawer
              },
            );
          }).toList(),
        ],
      ),
    );
  }
}
