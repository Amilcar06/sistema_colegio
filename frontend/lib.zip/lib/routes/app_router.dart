import 'package:go_router/go_router.dart';

import '../features/auth/ui/login_page.dart';
import '../features/splash/ui/splash_page.dart';
import '../features/director/pages/dashboard_director.dart';
import '../features/secretaria/pages/dashboard_secretaria.dart';
import '../features/profesor/pages/dashboard_profesor.dart';
import '../features/alumno/pages/dashboard_alumno.dart';

// Director Pages
import '../features/director/pages/dashboard_director_stats_page.dart';
import '../features/director/pages/dashboard_director_inscripciones_page.dart';
import '../features/director/pages/dashboard_director_profesores_page.dart';
import '../features/director/pages/dashboard_director_estudiantes_page.dart';
import '../features/director/pages/dashboard_director_cursos_page.dart';
import '../features/director/pages/dashboard_director_materias_page.dart';
import '../features/director/pages/dashboard_director_asignaciones_page.dart';
import '../features/director/pages/dashboard_director_horarios_page.dart';
import '../features/director/pages/dashboard_director_eventos_page.dart';
import '../features/director/pages/dashboard_director_comunicados_generales_page.dart';
import '../features/director/pages/dashboard_director_comunicados_curso_page.dart';
import '../features/director/pages/dashboard_director_pagos_page.dart';
import '../features/director/pages/dashboard_director_tipo_pension_page.dart';
import '../features/director/pages/dashboard_director_notas_page.dart';
import '../features/director/pages/dashboard_director_usuarios_page.dart';

// Secretaria Pages
import '../features/secretaria/pages/dashboard_secretaria_estudiantes_page.dart';
import '../features/secretaria/pages/dashboard_secretaria_inscripciones_page.dart';
import '../features/secretaria/pages/dashboard_secretaria_cursos_page.dart';
import '../features/secretaria/pages/dashboard_secretaria_pagos_page.dart';
import '../features/secretaria/pages/dashboard_secretaria_comprobantes_page.dart';
import '../features/secretaria/pages/dashboard_secretaria_facturacion_page.dart';
import '../features/secretaria/pages/dashboard_secretaria_eventos_page.dart';

// Profesor Pages
import '../features/profesor/pages/dashboard_profesor_cursos_page.dart';
import '../features/profesor/pages/dashboard_profesor_horarios_page.dart';
import '../features/profesor/pages/dashboard_profesor_inscritos_page.dart';
import '../features/profesor/pages/dashboard_profesor_notas_page.dart';
import '../features/profesor/pages/dashboard_profesor_comunicados_page.dart';

// Alumno Pages
import '../features/alumno/pages/dashboard_alumno_notas_page.dart';
import '../features/alumno/pages/dashboard_alumno_pagos_page.dart';
import '../features/alumno/pages/dashboard_alumno_comprobantes_page.dart';
import '../features/alumno/pages/dashboard_alumno_eventos_page.dart';
import '../features/alumno/pages/dashboard_alumno_comunicados_page.dart';
import '../features/alumno/pages/dashboard_alumno_horarios_page.dart';

final GoRouter appRouter = GoRouter(
  initialLocation: '/splash',
  routes: [
    GoRoute(
      path: '/splash',
      builder: (_, __) => const SplashPage(),
    ),
    GoRoute(
      path: '/login',
      builder: (_, __) => const LoginPage(),
    ),

    // Director
    GoRoute(
      path: '/dashboard-director',
      builder: (_, __) => const DashboardDirector(),
    ),
    GoRoute(
      path: '/dashboard-director/stats',
      builder: (_, __) => const DashboardDirectorStatsPage(),
    ),
    GoRoute(
      path: '/dashboard-director/inscripciones',
      builder: (_, __) => const DashboardDirectorInscripcionesPage(),
    ),
    GoRoute(
      path: '/dashboard-director/profesores',
      builder: (_, __) => const DashboardDirectorProfesoresPage(),
    ),
    GoRoute(
      path: '/dashboard-director/estudiantes',
      builder: (_, __) => const DashboardDirectorEstudiantesPage(),
    ),
    GoRoute(
      path: '/dashboard-director/cursos',
      builder: (_, __) => const DashboardDirectorCursosPage(),
    ),
    GoRoute(
      path: '/dashboard-director/materias',
      builder: (_, __) => const DashboardDirectorMateriasPage(),
    ),
    GoRoute(
      path: '/dashboard-director/asignaciones',
      builder: (_, __) => const DashboardDirectorAsignacionesPage(),
    ),
    GoRoute(
      path: '/dashboard-director/horarios',
      builder: (_, __) => const DashboardDirectorHorariosPage(),
    ),
    GoRoute(
      path: '/dashboard-director/eventos',
      builder: (_, __) => const DashboardDirectorEventosPage(),
    ),
    GoRoute(
      path: '/dashboard-director/comunicados-generales',
      builder: (_, __) => const DashboardDirectorComunicadosGeneralesPage(),
    ),
    GoRoute(
      path: '/dashboard-director/comunicados-curso',
      builder: (_, __) => const DashboardDirectorComunicadosCursoPage(),
    ),
    GoRoute(
      path: '/dashboard-director/pagos',
      builder: (_, __) => const DashboardDirectorPagosPage(),
    ),
    GoRoute(
      path: '/dashboard-director/tipo-pension',
      builder: (_, __) => const DashboardDirectorTipoPensionPage(),
    ),
    GoRoute(
      path: '/dashboard-director/notas',
      builder: (_, __) => const DashboardDirectorNotasPage(),
    ),
    GoRoute(
      path: '/dashboard-director/usuarios',
      builder: (_, __) => const DashboardDirectorUsuariosPage(),
    ),

    // Secretaria
    GoRoute(
      path: '/dashboard-secretaria',
      builder: (_, __) => const DashboardSecretaria(),
    ),
    GoRoute(
      path: '/dashboard-secretaria/estudiantes',
      builder: (_, __) => const DashboardSecretariaEstudiantesPage(),
    ),
    GoRoute(
      path: '/dashboard-secretaria/inscripciones',
      builder: (_, __) => const DashboardSecretariaInscripcionesPage(),
    ),
    GoRoute(
      path: '/dashboard-secretaria/cursos',
      builder: (_, __) => const DashboardSecretariaCursosPage(),
    ),
    GoRoute(
      path: '/dashboard-secretaria/pagos',
      builder: (_, __) => const DashboardSecretariaPagosPage(),
    ),
    GoRoute(
      path: '/dashboard-secretaria/comprobantes',
      builder: (_, __) => const DashboardSecretariaComprobantesPage(),
    ),
    GoRoute(
      path: '/dashboard-secretaria/facturacion',
      builder: (_, __) => const DashboardSecretariaFacturacionPage(),
    ),
    GoRoute(
      path: '/dashboard-secretaria/eventos',
      builder: (_, __) => const DashboardSecretariaEventosPage(),
    ),

    // Profesor
    GoRoute(
      path: '/dashboard-profesor',
      builder: (_, __) => const DashboardProfesor(),
    ),
    GoRoute(
      path: '/dashboard-profesor/cursos',
      builder: (_, __) => const DashboardProfesorCursosPage(),
    ),
    GoRoute(
      path: '/dashboard-profesor/horarios',
      builder: (_, __) => const DashboardProfesorHorariosPage(),
    ),
    GoRoute(
      path: '/dashboard-profesor/inscritos',
      builder: (_, __) => const DashboardProfesorInscritosPage(),
    ),
    GoRoute(
      path: '/dashboard-profesor/notas',
      builder: (_, __) => const DashboardProfesorNotasPage(),
    ),
    GoRoute(
      path: '/dashboard-profesor/comunicados',
      builder: (_, __) => const DashboardProfesorComunicadosPage(),
    ),

    // Alumno
    GoRoute(
      path: '/dashboard-alumno',
      builder: (_, __) => const DashboardAlumno(),
    ),
    GoRoute(
      path: '/dashboard-alumno/notas',
      builder: (_, __) => const DashboardAlumnoNotasPage(),
    ),
    GoRoute(
      path: '/dashboard-alumno/pagos',
      builder: (_, __) => const DashboardAlumnoPagosPage(),
    ),
    GoRoute(
      path: '/dashboard-alumno/comprobantes',
      builder: (_, __) => const DashboardAlumnoComprobantesPage(),
    ),
    GoRoute(
      path: '/dashboard-alumno/eventos',
      builder: (_, __) => const DashboardAlumnoEventosPage(),
    ),
    GoRoute(
      path: '/dashboard-alumno/comunicados',
      builder: (_, __) => const DashboardAlumnoComunicadosPage(),
    ),
    GoRoute(
      path: '/dashboard-alumno/horarios',
      builder: (_, __) => const DashboardAlumnoHorariosPage(),
    ),
  ],
);
