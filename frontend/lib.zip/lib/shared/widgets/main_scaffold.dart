// lib/widgets/main_scaffold.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../state/auth_provider.dart';
import 'package:provider/provider.dart';
import '../widgets/side_menu.dart';
import '../widgets/bottom_nav.dart';
import 'menu/menu_items.dart'; // define menuPorRol

class MainScaffold extends StatelessWidget {
  final Widget child;

  const MainScaffold({required this.child, super.key});

  @override
  Widget build(BuildContext context) {
    final rol = context.read<AuthProvider>().rol ?? 'alumno';
    final menu = menuPorRol[rol] ?? [];

    final isAdmin = rol == 'director' || rol == 'secretaria';

    return Scaffold(
      appBar: AppBar(title: const Text('Portal Educativo')),
      drawer: isAdmin ? SideMenu(menu: menu) : null,
      bottomNavigationBar: !isAdmin ? BottomNav(menu: menu) : null,
      body: child,
    );
  }
}
