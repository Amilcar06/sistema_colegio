import 'package:flutter/material.dart';
import '../../../shared/widgets/main_scaffold.dart';

class DashboardProfesorHorariosPage extends StatelessWidget {
  const DashboardProfesorHorariosPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const MainScaffold(
      child: Center(child: Text('Página: Horarios')),
    );
  }
}
